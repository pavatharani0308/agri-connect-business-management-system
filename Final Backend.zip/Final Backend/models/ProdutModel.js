const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const ProductSchema = new Schema({
    name: {
        type: String
    },
    category: {
        type: String,
        required: false
    },
    qty: {
        type: Number
    },
    price: {
        type: Number
    },
    manufacturer: {
        type: Date,
        required: false
    },
    expiryDate: {
        type: Date,
        required: false
    },
    status: {
        type: String,
        enum: ['In Stock', 'Out of Stock'],
        default: 'In Stock'
    },
    description: {
        type: String,
        required: false
    },
    productimage: {
        type: String,
        required: false
    },
    productid: {
        type: String
    }
}, { timestamps: true });  // adds createdAt & updatedAt automatically

// Export model
const ProductModel = mongoose.model('Product', ProductSchema);
module.exports = ProductModel;
