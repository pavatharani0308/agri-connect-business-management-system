// models/Feedback.js
const mongoose = require('mongoose');

const replySchema = new mongoose.Schema({
  adminReply: { type: String, required: true },
  date: { type: Date, default: Date.now }
});

const feedbackSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  message: { type: String, required: true },
  replies: [replySchema], // Add replies array
  date: { type: Date, default: Date.now },
  likes: {
    type: Number,
    default: 0,
  },
  likedBy: { // Add likedBy array to track users who liked the feedback
    type: [String], // This could be an array of user IDs (strings)
    default: [], // Default to an empty array
  },
});

const Feedback = mongoose.model('Feedback', feedbackSchema);

module.exports = Feedback;
