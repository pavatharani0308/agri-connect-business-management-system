const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'Buyer', required: true },
  items: [{
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    quantity: { type: Number, required: true },
    price: { type: Number, required: true },
  }],
  total: { type: Number, required: true },
  paymentMethod: { type: String, enum: ['COD', 'CARD'], required: true },
  status: { type: String, enum: ['PENDING', 'DONE', 'REFUND', 'CANCELLED', "REFUND REQUESTED"], required: true },
  deliveryDetails: {
    name: { type: String, required: function () { return this.paymentMethod === 'COD'; } },
    phone: { type: String, required: function () { return this.paymentMethod === 'COD'; } },
    address: { type: String, required: function () { return this.paymentMethod === 'COD'; } },
  },
  refundReason: { type: String },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Order', orderSchema);