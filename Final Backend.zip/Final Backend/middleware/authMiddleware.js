// Simple authentication middleware
// Since this is a basic feedback system, we'll create a simple auth middleware
// In a production environment, you'd want to use JWT or other proper authentication

const authMiddleware = (req, res, next) => {
  // For now, we'll allow all requests through
  // You can implement proper authentication logic here later
  
  // Example: Check for authorization header
  const authHeader = req.headers.authorization;
  
  if (!authHeader) {
    // For development, we'll allow requests without authentication
    // In production, you should return an error
    console.log('No authorization header found - allowing request for development');
    return next();
  }

  // Extract token from "Bearer TOKEN"
  const token = authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ message: 'Access denied. No token provided.' });
  }

  try {
    // In a real application, you would verify the JWT token here
    // For now, we'll just pass through
    console.log('Token found:', token);
    
    // You would typically decode the JWT token here
    // const decoded = jwt.verify(token, process.env.JWT_SECRET);
    // req.user = decoded;
    
    next();
  } catch (error) {
    res.status(400).json({ message: 'Invalid token.' });
  }
};

module.exports = authMiddleware;