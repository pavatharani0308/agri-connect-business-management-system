

const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const { router: authRoutes } = require('./routes/auth');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const path = require('path');


dotenv.config();
const app = express();

app.use(helmet());
// CORS configuration
app.use(cors({
    origin: ['http://localhost:5173', 'http://localhost:3000', 'process.env.FRONTEND_URL'],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(cookieParser());

// Parse JSON except for webhook
// app.use((req, res, next) => {
//     if (req.originalUrl === '/api/payments/webhook') {
//         next();
//     } else {
//         express.json()(req, res, next);
//     }
// });
app.use('/api/payments', require('./routes/payments'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', authRoutes);
// app.use('/api/products', require('./routes/products'));
app.use('/api/cart', require('./routes/cart'));
app.use('/api/orders', require('./routes/orders'));

app.use('/api/admin', require('./routes/adminRoutes'));
app.use('/api/seller', require('./routes/sellerRoutes'));
app.use('/api/buyer', require('./routes/buyerRoutes'));

const ProductRouter = require('./routes/ProductRouter');
app.use('/api/products', ProductRouter);

// Serve static files from uploads directory
// app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use(
    "/uploads",
    express.static(path.join(process.cwd(), "uploads"), {
        setHeaders: (res, path, stat) => {
            res.set("Access-Control-Allow-Origin", "*");
        },
    })
);

// Routes
const feedbackRoutes = require('./routes/FeedbackRoutes');
const complaintRoutes = require('./routes/ComplaintRoutes');
app.use('/api', feedbackRoutes);
app.use('/api', complaintRoutes);

// Create uploads directory if it doesn't exist
const fs = require('fs');
const uploadsDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
}

// Basic route
app.get('/', (req, res) => {
    res.json({
        message: 'AgriManager API - Agriculture Business Management System',
        version: '1.0.0',
        status: 'Server is running successfully!',
        description: 'Complete agricultural management platform API',
        features: [
            'Crop Management',
            'Financial Tracking',
            'Equipment Management',
            'Weather Integration',
            'Inventory Control',
            'Mobile Access'
        ],
        database: 'MongoDB Connected',
        environment: process.env.NODE_ENV
    });
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        service: 'AgriManager API',
        timestamp: new Date().toISOString(),
        environment: process.env.NODE_ENV,
        database: 'Connected to MongoDB',
        uptime: process.uptime(),
        memory: process.memoryUsage()
    });
});

// 404 handler
app.use(/.*/, (req, res) => {
    res.status(404).json({
        message: 'Route not found',
        path: req.originalUrl
    });
});

// Global error handler
app.use((error, req, res, next) => {
    console.error('Error:', error);
    res.status(error.status || 500).json({
        message: error.message || 'Internal server error',
        ...(process.env.NODE_ENV === 'development' && { stack: error.stack })
    });
});

mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => console.log('Connected to MongoDB'))
    .catch((err) => console.error('MongoDB connection error:', err));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
