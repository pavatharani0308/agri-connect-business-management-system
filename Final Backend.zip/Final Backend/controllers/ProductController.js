const ProductModel = require("../Models/ProdutModel");

const createProduct = async (req,res) => {
    try{
        const body = req.body;

        body.productimage = req.file ? req.file?.path :null;

        console.log(body); 
        const product = new ProductModel(body);
        await product.save();

        res.status(201)
        .json({
            message: `Products Added`,
            success:true,
            data:product
        });
    }catch(err){
        res.status(400).json({
            message:`internal server error`,
            success: false,
            error:err
        })
    }

 
}

const updateProdutById = async (req,res) => {
    try{
        const {name, category, qty, price, manufacturer, expiryDate, status, description, productid } = req.body;
        const {id}= req.params;
     
        let updateDate ={name, category, qty, price, manufacturer, expiryDate, status, description, productid ,updatedAt: new Date() };
       
        if(req.file){
            updateDate.productimage = req.file.path;
        }
        const updateProduct = await ProductModel.findByIdAndUpdate(
            id,
            updateDate,
            {new:true}
        );

        if(!updateProduct){
            return res.status(404).json({message:`Product not found`});
        }

        res.status(200)
        .json({
            message: `Products Updated`,
            success:true,
            data:updateProduct
        });
    }catch(err){
        res.status(400).json({
            message:`internal server error`,
            success: false,
            error:err.message
        });
    }

 
};

const getAllProducts = async (req,res) => {
    try{
       let{page, limit, search} = req.query;

       page = parseInt(page) || 1;
       limit = parseInt(limit) || 5;


       const skip = (page - 1) * limit;

       let searchCriteria ={};
       if(search){
         searchCriteria ={
            name:{
                $regex:search,
                $options:`i`
            }
         }
       }
       const totalProducts = await ProductModel.countDocuments(searchCriteria);

        const products = await ProductModel.find(searchCriteria)
        .skip(skip)
        .limit(limit)
        .sort({updatedAt: -1});

        const totalpages = Math.ceil(totalProducts/ limit);
        res.status(200)
        .json({
            message: `All Products`,
            success:true,
            data:{
                products:products, 
                pagination: {
                    totalProducts,
                    currentPage:page,
                    totalpages,
                    pageSize:limit
                }
            }
        });
    }catch(err){
        console.log(err)
        res.status(400).json({
            message:`internal server error`,
            success: false,
            error:err
        })
    }

 
}

const getProductByID = async (req,res) => {
    try{
        const {id} = req.params;
        const product = await ProductModel.findOne({_id:id});

        res.status(200)
        .json({
            message: `Get Products Details`,
            success:true,
            data:product
        });
    }catch(err){
        res.status(400).json({
            message:`internal server error`,
            success: false,
            error:err
        })
    }

 
}
const deleteProductByID = async (req,res) => {
    try{
        const {id} = req.params;
        console.log('Deleting product with ID:', id);
        const product = await ProductModel.findByIdAndDelete({_id:id});

        if (!product) {
            return res.status(404).json({
                message: 'Product not found',
                success: false
            });
        }

        console.log('Product deleted successfully:', product.name);
        res.status(200).json({
            message: 'Product deleted',
            success: true
        });
    }catch(err){
        console.error('Delete error:', err);
        res.status(400).json({
            message: 'Internal server error',
            success: false,
            error: err.message
        })
    }
}
module.exports={
    createProduct,
    getAllProducts,
    getProductByID,
    deleteProductByID,
    updateProdutById
}