const express = require('express');
const Cart = require('../models/Cart');
const { verifyToken } = require('./auth');
const router = express.Router();
const jwt = require('jsonwebtoken');

// Get user's cart
router.get('/', verifyToken, async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    let cart = await Cart.findOne({ userId: decoded.id }).populate('items.productId');
    if (!cart) cart = new Cart({ userId: decoded.id, items: [] });
    res.json(cart);
  } catch (err) {
    res.status(500).json(err);
  }
});

// Add item to cart
router.post('/add', verifyToken, async (req, res) => {
  const { productId, quantity = 1 } = req.body;
  const authHeader = req.headers.authorization;
  const token = authHeader.split(' ')[1];
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  try {
    let cart = await Cart.findOne({ userId: decoded.id });
    if (!cart) cart = new Cart({ userId: decoded.id, items: [] });

    const itemIndex = cart.items.findIndex(item => item.productId.toString() === productId);
    if (itemIndex > -1) {
      cart.items[itemIndex].quantity += quantity;
    } else {
      cart.items.push({ productId, quantity, userId: decoded.id });
    }

    const populatedCart = await cart.populate('items.productId');
    cart.total = populatedCart.items.reduce((acc, item) => acc + (item.productId.price * item.quantity), 0);

    await cart.save();
    res.json(cart);
  } catch (err) {
    res.status(400).json(err);
  }
});

// Update item quantity
router.put('/update/:productId', verifyToken, async (req, res) => {
  const { quantity } = req.body;
  const authHeader = req.headers.authorization;
  const token = authHeader.split(' ')[1];
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  try {
    const cart = await Cart.findOne({ userId: decoded.id });
    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    const itemIndex = cart.items.findIndex(item => item.productId.toString() === req.params.productId);
    if (itemIndex > -1) {
      cart.items[itemIndex].quantity = Math.max(1, quantity); // Min 1
    }

    const populatedCart = await cart.populate('items.productId');
    cart.total = populatedCart.items.reduce((acc, item) => acc + (item.productId.price * item.quantity), 0);

    await cart.save();
    res.json(cart);
  } catch (err) {
    res.status(400).json(err);
  }
});

// Remove item
router.delete('/remove/:productId', verifyToken, async (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader.split(' ')[1];
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  try {
    const cart = await Cart.findOne({ userId: decoded.id });
    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    cart.items = cart.items.filter(item => item.productId.toString() !== req.params.productId);

    const populatedCart = await cart.populate('items.productId');
    cart.total = populatedCart.items.reduce((acc, item) => acc + (item.productId.price * item.quantity), 0);

    await cart.save();
    res.json(cart);
  } catch (err) {
    res.status(500).json(err);
  }
});

// Apply discount (simple validation)
router.post('/apply-discount', verifyToken, async (req, res) => {
  const { code } = req.body;
  const authHeader = req.headers.authorization;
  const token = authHeader.split(' ')[1];
  const decoded = jwt.verify(token, process.env.JWT_SECRET);
  try {
    const cart = await Cart.findOne({ userId: decoded.id }).populate('items.productId');
    if (!cart) return res.status(404).json({ message: 'Cart not found' });

    let discount = 0;
    if (code === 'FARMER') { // Simple code for 10% off
      discount = cart.total * 0.1;
      cart.total -= discount; // Apply discount
      cart.discount = discount; // Store discount
      await cart.save();
      res.json({ cart, message: 'Discount applied' });
    } else {
      res.status(400).json({ message: 'Invalid discount code' });
    }
  } catch (err) {
    res.status(500).json(err);
  }
});

module.exports = router;