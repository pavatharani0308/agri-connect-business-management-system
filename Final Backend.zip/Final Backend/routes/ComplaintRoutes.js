const express = require('express');
const router = express.Router();
const complaintController = require('../controllers/ComplaintController');

// Complaint routes
router.get('/complaints', complaintController.getAllComplaints);
router.post('/complaints', complaintController.addComplaint);
router.get('/complaints/:id', complaintController.getComplaintById);
router.put('/complaints/:id', complaintController.updateComplaintById);
router.delete('/complaints/:id', complaintController.deleteComplaintById);

module.exports = router;