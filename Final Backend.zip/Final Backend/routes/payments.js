const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const Cart = require('../models/Cart');
const Order = require('../models/Order');
const User = require('../models/User');
const Buyer = require('../models/Buyer');
const { verifyToken } = require('./auth');
require('dotenv').config();

// Create Stripe checkout session
router.post('/create-checkout-session', verifyToken, async (req, res) => {
  try {
    if (!req.user.id) {
      return res.status(401).json({ message: 'User ID missing in token' });
    }

    const cart = await Cart.findOne({ userId: req.user.id }).populate('items.productId');
    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: 'Cart is empty or not found' });
    }

    const user = await Buyer.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const lineItems = cart.items.map(item => ({
      price_data: {
        currency: 'usd',
        product_data: {
          name: item.productId.name,
        },
        unit_amount: Math.round(item.productId.price * 100),
      },
      quantity: item.quantity,
    }));

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: lineItems,
      mode: 'payment',
      success_url: 'http://localhost:5173/buyer-dashboard',
      cancel_url: 'http://localhost:5173/cart',
      customer_email: user.email,
      metadata: {
        userId: user.id,
        cartId: cart._id.toString(),
      },
    });

    console.log('Checkout session created:', {
      id: session.id,
      email: user.email,
      mode: 'Test',
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error('Error creating checkout session:', err.message);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// Stripe webhook for checkout.session.completed
// router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
//   const sig = req.headers['stripe-signature'];
//   let event;

//   try {
//     event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
//   } catch (err) {
//     console.error('Webhook signature verification failed:', err.message);
//     return res.status(400).json({ message: 'Webhook error' });
//   }

//   if (event.type === 'checkout.session.completed') {
//     const session = event.data.object;
//     console.log('Processing checkout.session.completed:', {
//       session: session.id,
//       user: session.metadata.userId,
//       email: session.customer_email,
//     });

//     try {

//       const userId = session.metadata.userId;
//       const cartId = session.metadata.cartId;

//       if (!mongoose.isValidObjectId(userId) || !mongoose.isValidObjectId(cartId)) {
//         throw new Error('Invalid user ID or cart ID');
//       }

//       const cart = await Cart.findById(cartId).populate('items.productId');
//       if (!cart || cart.items.length === 0) {
//         throw new Error('Cart is empty or not found');
//       }

//       const orderItems = cart.items.map(item => ({
//         productId: item.productId._id,
//         quantity: item.quantity,
//         price: item.productId.price,
//       }));

//       const order = new Order({
//         userId,
//         items: orderItems,
//         total: cart.total,
//         paymentMethod: 'CARD',
//         status: 'DONE',
//         deliveryDetails: {}, // Empty for card payments
//       });

//       await order.save();
//       await Cart.deleteOne({ _id: cartId });
//     } catch (err) {
//       console.error('Webhook processing error:', err.message);
//       return res.status(400).json({ message: 'Webhook processing error', error: err.message });
//     }
//   }

//   res.json({ received: true });
// });

router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  const sig = req.headers['stripe-signature'];

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('❌ Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    console.log('✅ Checkout completed:', session.id);

    try {
      const userId = session.metadata.userId;
      const cartId = session.metadata.cartId;

      if (!mongoose.isValidObjectId(userId) || !mongoose.isValidObjectId(cartId)) {
        throw new Error('Invalid user ID or cart ID');
      }

      const cart = await Cart.findById(cartId).populate('items.productId');
      if (!cart || cart.items.length === 0) {
        throw new Error('Cart is empty or not found');
      }

      const orderItems = cart.items.map(item => ({
        productId: item.productId._id,
        quantity: item.quantity,
        price: item.productId.price,
      }));

      const order = new Order({
        userId,
        items: orderItems,
        total: cart.total,
        paymentMethod: 'CARD',
        status: 'DONE',
        deliveryDetails: {},
      });

      await order.save();
      await Cart.deleteOne({ _id: cartId });
    } catch (err) {
      console.error('Webhook processing error:', err.message);
      return res.status(400).json({ message: 'Webhook processing error', error: err.message });
    }
  }

  res.json({ received: true });
});
module.exports = router;