const {
  createProduct,
  getAllProducts,
  getProductByID,
  deleteProductByID,
  updateProdutById
} = require("../controllers/ProductController");

const { cloudinaryFileUploader } = require("../middleware/FileUploader");

const routes = require('express').Router();

// Get all products
routes.get('/', getAllProducts);

// Create new product with image upload
routes.post('/', cloudinaryFileUploader.single('productimage'), createProduct);

// Update product by ID
routes.put('/:id', cloudinaryFileUploader.single('productimage'), updateProdutById);

// Get single product by ID
routes.get('/:id', getProductByID);

// Delete product by ID
routes.delete('/:id', deleteProductByID);

module.exports = routes;
