const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');
const Order = require('../models/Order');
const Cart = require('../models/Cart');
const User = require('../models/User');
const Buyer = require('../models/Buyer');
const Admin = require('../models/Admin');
const { verifyToken } = require('./auth');
const nodemailer = require('nodemailer');
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
const jwt = require('jsonwebtoken');
require('dotenv').config();
const cron = require('node-cron');
const fs = require('fs-extra');
const PDFDocument = require('pdfkit');
const moment = require('moment');
const path = require('path');
fs.ensureDirSync('../reports/daily');
fs.ensureDirSync('../reports/monthly');

// Get user's orders
router.get('/', verifyToken, async (req, res) => {
  try {
    console.log('User orders route userId:', req.user.id);
    if (!req.user.id) {
      return res.status(401).json({ message: 'User ID missing in token' });
    }
    const orders = await Order.find({ userId: req.user.id }).populate('items.productId');
    res.json(orders);
  } catch (err) {
    console.error('Error fetching user orders:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Admin: Get all orders with search, sort, filter
router.get('/admin', verifyToken, async (req, res) => {
  try {
    console.log('Admin route userId:', req.user.id);
    const user = await Admin.findById(req.user.id);
    console.log('Admin route user:', user);

    if (!user || user.role !== 'admin') {
      return res.status(403).json({ message: 'Admin access required' });
    }

    let query = Order.find()
      .populate('items.productId')
      .populate('userId', 'email');

    const { search, sortBy, sortDir, paymentMethod, status } = req.query;

    if (search) {
      query = query.find({
        $or: [
          // ✅ convert _id to string before regex
          { $expr: { $regexMatch: { input: { $toString: '$_id' }, regex: search, options: 'i' } } },
          { 'userId.email': { $regex: search, $options: 'i' } },
        ],
      });
    }

    if (paymentMethod) {
      query = query.where('paymentMethod', paymentMethod);
    }

    if (status) {
      query = query.where('status', status);
    }

    if (sortBy && sortDir) {
      query = query.sort({ [sortBy]: sortDir === 'desc' ? -1 : 1 });
    } else {
      query = query.sort({ createdAt: -1 });
    }

    const orders = await query.exec();
    console.log('Admin route orders:', orders);
    res.json(orders);
  } catch (err) {
    console.error('Error fetching admin orders:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});


// Get single order (admin only)
router.get('/:orderId', verifyToken, async (req, res) => {
  try {
    const user = await Admin.findById(req.user.id);
    console.log('Single order route user:', user);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ message: 'Admin access required' });
    }

    if (!mongoose.isValidObjectId(req.params.orderId)) {
      return res.status(400).json({ message: 'Invalid order ID' });
    }

    const order = await Order.findById(req.params.orderId)
      .populate('items.productId')
      .populate('userId', 'email username');
    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    res.json(order);
  } catch (err) {
    console.error('Error fetching order:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Admin: Update order status
router.put('/admin/:orderId', verifyToken, async (req, res) => {
  try {
    const user = await Admin.findById(req.user.id);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ message: 'Admin access required' });
    }

    if (!mongoose.isValidObjectId(req.params.orderId)) {
      return res.status(400).json({ message: 'Invalid order ID' });
    }


    const { status, refundReason } = req.body;
    const updateData = { status };
    if (refundReason !== undefined) {
      updateData.refundReason = refundReason;
    }
    const order = await Order.findByIdAndUpdate(
      req.params.orderId,
      updateData,
      { new: true }
    ).populate('items.productId').populate('userId', 'email');

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    if ((order.paymentMethod === 'COD' || order.paymentMethod === 'CARD') && (status === 'DONE' || status === 'REFUND' || status === 'PENDING')) {
      await sendStatusUpdateEmail(order);
    }

    res.json({ order, message: 'Status updated successfully' });
  } catch (err) {
    console.error('Error updating order:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/user/order', verifyToken, async (req, res) => {
  try {
    // const admin = await User.findById(req.user.id);
    // if (!admin || admin.role !== 'admin') {
    //   return res.status(403).json({ message: 'Admin access required' });
    // }
    const authHeader = req.headers.authorization;
    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const userId = decoded.id;
    console.log("user id", decoded.id);

    if (!mongoose.isValidObjectId(userId)) {
      return res.status(400).json({ message: 'Invalid user ID' });
    }

    // Fetch all orders for that user
    const orders = await Order.find({ userId })
      .populate('items.productId')
      .populate('userId', 'email username')
      .sort({ createdAt: -1 });

    console.log("Customer order", orders.length);


    if (!orders || orders.length === 0) {
      return res.status(404).json({ message: 'No orders found for this user' });
    }

    res.json({ userId, totalOrders: orders.length, orders });
  } catch (err) {
    console.error('Error fetching orders by userId:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});


// COD order creation
router.post('/cod', verifyToken, async (req, res) => {
  try {
    console.log('COD order userId:', req.user.id);
    if (!req.user.id) {
      return res.status(401).json({ message: 'User ID missing in token' });
    }

    let { address, phone, name } = req.body;

    // Trim and validate empty or spaces
    address = address ? address.trim() : '';
    phone = phone ? phone.trim() : '';
    name = name ? name.trim() : '';

    if (!address || !phone || !name) {
      return res.status(400).json({ message: 'Delivery details required for COD' });
    }

    // ✅ Optional: strict phone validation (10 digits only, no spaces)
    const phoneRegex = /^\d{10}$/;
    if (!phoneRegex.test(phone)) {
      return res.status(400).json({ message: 'Phone number must be exactly 10 digits' });
    }

    let cart = await Cart.findOne({ userId: req.user.id }).populate('items.productId');
    if (!cart) {
      cart = new Cart({
        userId: req.user.id,
        items: [],
        total: 0,
      });
      await cart.save();
    }

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: 'Cart is empty' });
    }

    const orderItems = cart.items.map(item => ({
      productId: item.productId._id,
      quantity: item.quantity,
      price: item.productId.price,
    }));

    const order = new Order({
      userId: req.user.id,
      items: orderItems,
      total: cart.total,
      paymentMethod: 'COD',
      status: 'PENDING',
      deliveryDetails: { address, phone, name },
    });

    await order.save();
    await Cart.deleteOne({ userId: req.user.id });
    res.status(201).json({ order, message: 'COD order placed successfully' });
  } catch (err) {
    console.error('Error creating COD order:', err.message);
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// ==============================
// User: Cancel Order
// ==============================
router.put('/:orderId/cancel', verifyToken, async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.id
    const order = await Order.findOne({ _id: req.params.orderId, userId: userId });

    if (!order) {
      return res.status(404).json({ message: 'Order not found or not yours' });
    }

    if (order.status !== 'PENDING') {
      console.log("Status", order.status);

      return res.status(400).json({ message: 'Only pending orders can be cancelled' });
    }

    order.status = 'CANCELLED';
    await order.save();

    await sendStatusUpdateEmail(order);

    res.json({ message: 'Order cancelled successfully', order });
  } catch (err) {
    console.error('Cancel order error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});


// ==============================
// User: Request Refund
// ==============================
router.post('/:orderId/refund', verifyToken, async (req, res) => {
  try {
    const order = await Order.findOne({ _id: req.params.orderId, userId: req.user.id });

    if (!order) {
      return res.status(404).json({ message: 'Order not found or not yours' });
    }

    if (order.status !== 'DONE') {
      return res.status(400).json({ message: 'Refund available only for completed orders' });
    }

    // Check 30 days (1 month) window
    const now = new Date();
    const deliveredDate = new Date(order.updatedAt);
    const daysSinceDelivery = (now - deliveredDate) / (1000 * 60 * 60 * 24);

    if (daysSinceDelivery > 30) {
      return res.status(400).json({ message: 'Refund period expired (30 days)' });
    }

    const { reason } = req.body;
    if (!reason || reason.trim() === '') {
      return res.status(400).json({ message: 'Refund reason is required' });
    }

    order.status = 'REFUND REQUESTED';
    order.refundReason = reason;
    await order.save();

    res.json({ message: 'Refund request submitted', order });
  } catch (err) {
    console.error('Refund request error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});


// ==============================
// User: Add Feedback for an Order
// ==============================
router.post('/:orderId/feedback', verifyToken, async (req, res) => {
  try {
    const { rating, comment } = req.body;
    if (!rating || rating < 1 || rating > 5) {
      return res.status(400).json({ message: 'Rating (1–5) is required' });
    }

    const order = await Order.findOne({ _id: req.params.orderId, userId: req.user.id });
    if (!order) {
      return res.status(404).json({ message: 'Order not found or not yours' });
    }

    if (order.status !== 'DONE') {
      return res.status(400).json({ message: 'Feedback can only be added for completed orders' });
    }

    // Prevent duplicate feedback
    const existingFeedback = await Feedback.findOne({ orderId: order._id, userId: req.user.id });
    if (existingFeedback) {
      return res.status(400).json({ message: 'You have already given feedback for this order' });
    }

    const feedback = new Feedback({
      orderId: order._id,
      userId: req.user.id,
      rating,
      comment,
    });

    await feedback.save();
    res.status(201).json({ message: 'Feedback submitted successfully', feedback });
  } catch (err) {
    console.error('Feedback submission error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});


// ==============================
// User: Get Feedback for Their Orders
// ==============================
router.get('/feedback/my', verifyToken, async (req, res) => {
  try {
    const feedbacks = await Feedback.find({ userId: req.user.id })
      .populate('orderId', '_id status total createdAt')
      .sort({ createdAt: -1 });

    res.json(feedbacks);
  } catch (err) {
    console.error('Error fetching user feedback:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});


// ==============================
// Admin: View All Feedback
// ==============================
router.get('/admin/feedback', verifyToken, async (req, res) => {
  try {
    const user = await Admin.findById(req.user.id);
    if (!user || user.role !== 'admin') {
      return res.status(403).json({ message: 'Admin access required' });
    }

    const feedbacks = await Feedback.find()
      .populate('userId', 'email username')
      .populate('orderId', '_id status total')
      .sort({ createdAt: -1 });

    res.json(feedbacks);
  } catch (err) {
    console.error('Error fetching all feedback:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});




// Email service for status updates
// async function sendStatusUpdateEmail(order) {
//   console.log("order details", order);

//   const transporter = nodemailer.createTransport({
//     service: 'gmail',
//     auth: {
//       user: process.env.GMAIL_USER,
//       pass: process.env.GMAIL_PASS,
//     },
//   });

//   //   const emailTemplate = `
//   //     <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 8px;">
//   //       <h1 style="color: #28a745; text-align: center;">Agri Connect Order Update</h1>
//   //       <p>Dear ${order.deliveryDetails?.name || order.userId.email},</p>
//   //       <p>Your order #${order._id} has been updated.</p>
//   //       <ul style="list-style-type: none; padding: 0;">
//   //         <li><strong>Status:</strong> ${order.status.toUpperCase()}</li>
//   //         <li><strong>Payment Method:</strong> ${order.paymentMethod}</li>
//   //         <li><strong>Total:</strong> $${order.total}</li>
//   //         ${order.status === 'REFUND' ? `<li><strong>Refund Reason:</strong> ${order.refundReason}</li>` : ''}
//   //         ${order.deliveryDetails?.address ? `<li><strong>Address:</strong> ${order.deliveryDetails.address}</li>` : ''}
//   //       </ul>
//   //       <p>Thank you for shopping with Agri Connect!</p>
//   //       <p style="text-align: center; color: #666;">Best regards,<br>Agri Connect Team</p>
//   //     </div>
//   //   `;
//   const emailTemplate = `
// <div style="font-family: 'Arial', sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; background-color: #f9fdf7;">
//   <!-- Header -->
//   <div style="text-align: center; padding-bottom: 20px; border-bottom: 2px solid #c3e6cb;">
//     <h1 style="color: #2e7d32; margin: 0; font-size: 24px;">🌱 Agri Connect</h1>
//     <p style="color: #388e3c; margin-top: 5px; font-size: 16px;">Order Update Notification</p>
//   </div>

//   <!-- Greeting -->
//   <p style="font-size: 16px; color: #333; margin-top: 20px;">
//     Dear <strong>${order.deliveryDetails?.name || order.userId.email}</strong>,
//   </p>

//   <p style="font-size: 16px; color: #333;">
//     Your order <strong>#${order._id}</strong> has been updated. Here are the details:
//   </p>

//   <!-- Order Details Card -->
//   <div style="background-color: #e6f4ea; border-radius: 10px; padding: 15px; margin: 15px 0;">
//     <ul style="list-style-type: none; padding: 0; margin: 0; color: #2e7d32; font-size: 15px;">
//       <li style="margin-bottom: 8px;"><strong>Status:</strong> ${order.status.toUpperCase()}</li>
//       <li style="margin-bottom: 8px;"><strong>Payment Method:</strong> ${order.paymentMethod}</li>
//       <li style="margin-bottom: 8px;"><strong>Total:</strong> $${order.total}</li>
//       ${order.status === 'REFUND' ? `<li style="margin-bottom: 8px;"><strong>Refund Reason:</strong> ${order.refundReason}</li>` : ''}
//       ${order.deliveryDetails?.address ? `<li style="margin-bottom: 8px;"><strong>Address:</strong> ${order.deliveryDetails.address}</li>` : ''}
//     </ul>
//   </div>

//   <!-- Footer -->
//   <p style="font-size: 16px; color: #333;">Thank you for shopping with <strong>Agri Connect</strong>! 🌾</p>

//   <div style="text-align: center; margin-top: 30px; font-size: 14px; color: #666;">
//     Best regards,<br>
//     <strong>Agri Connect Team</strong>
//   </div>

//   <!-- Optional Decorative Footer -->
//   <div style="margin-top: 20px; text-align: center;">
//     <span style="font-size: 24px;">🥕🌽🍅🌾</span>
//   </div>
// </div>
// `;


//   const mailOptions = {
//     from: process.env.GMAIL_USER,
//     to: order.userId.email,
//     subject: `Agri Connect - Order #${order._id} Status Update: ${order.status.toUpperCase()}`,
//     html: emailTemplate,
//   };

//   await transporter.sendMail(mailOptions);
//   console.log(`Status update email sent to: ${order.userId.email}`);
// }

async function sendStatusUpdateEmail(order) {
  console.log("order details", order);

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: process.env.GMAIL_USER,
      pass: process.env.GMAIL_PASS,
    },
  });

  // ✅ Ensure email exists
  let userEmail = order?.userId?.email;

  if (!userEmail && order.userId) {
    try {
      // 👇 Fetch from Buyer collection instead of User
      const buyer = await Buyer.findById(order.userId).select('email');
      userEmail = buyer?.email;
    } catch (err) {
      console.error("Error fetching buyer email:", err.message);
    }
  }

  if (!userEmail) {
    console.error("❌ No buyer email found for order:", order._id);
    return;
  }

  const emailTemplate = `
  <div style="font-family: 'Arial', sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; background-color: #f9fdf7;">
    <div style="text-align: center; padding-bottom: 20px; border-bottom: 2px solid #c3e6cb;">
      <h1 style="color: #2e7d32; margin: 0; font-size: 24px;">🌱 Agri Connect</h1>
      <p style="color: #388e3c; margin-top: 5px; font-size: 16px;">Order Update Notification</p>
    </div>

    <p style="font-size: 16px; color: #333; margin-top: 20px;">
      Dear <strong>${order.deliveryDetails?.name || userEmail}</strong>,
    </p>

    <p style="font-size: 16px; color: #333;">
      Your order <strong>#${order._id}</strong> has been updated. Here are the details:
    </p>

    <div style="background-color: #e6f4ea; border-radius: 10px; padding: 15px; margin: 15px 0;">
      <ul style="list-style-type: none; padding: 0; margin: 0; color: #2e7d32; font-size: 15px;">
        <li style="margin-bottom: 8px;"><strong>Status:</strong> ${order.status.toUpperCase()}</li>
        <li style="margin-bottom: 8px;"><strong>Payment Method:</strong> ${order.paymentMethod}</li>
        <li style="margin-bottom: 8px;"><strong>Total:</strong> $${order.total}</li>
        ${order.status === 'REFUND' ? `<li style="margin-bottom: 8px;"><strong>Refund Reason:</strong> ${order.refundReason}</li>` : ''}
        ${order.deliveryDetails?.address ? `<li style="margin-bottom: 8px;"><strong>Address:</strong> ${order.deliveryDetails.address}</li>` : ''}
      </ul>
    </div>

    <p style="font-size: 16px; color: #333;">Thank you for shopping with <strong>Agri Connect</strong>! 🌾</p>
    <div style="text-align: center; margin-top: 30px; font-size: 14px; color: #666;">
      Best regards,<br>
      <strong>Agri Connect Team</strong>
    </div>

    <div style="margin-top: 20px; text-align: center;">
      <span style="font-size: 24px;">🥕🌽🍅🌾</span>
    </div>
  </div>`;

  const mailOptions = {
    from: process.env.GMAIL_USER,
    to: userEmail,
    subject: `Agri Connect - Order #${order._id} Status Update: ${order.status.toUpperCase()}`,
    html: emailTemplate,
  };

  await transporter.sendMail(mailOptions);
  console.log(`✅ Status update email sent to: ${userEmail}`);
}


// report section
// Generate PDF Function
async function generatePDFReport(orders, filePath, title = 'Order Report') {
  return new Promise((resolve, reject) => {
    try {
      const doc = new PDFDocument({
        size: 'A4',
        margin: 40,
        bufferPages: true
      });

      const stream = fs.createWriteStream(filePath);
      doc.pipe(stream);

      // Color scheme
      const colors = {
        primary: '#2c3e50',
        secondary: '#34495e',
        accent: '#3498db',
        border: '#bdc3c7',
        lightBg: '#ecf0f1',
        text: '#2c3e50',
        lightText: '#7f8c8d',
        success: '#27ae60',
        warning: '#f39c12'
      };

      const pageWidth = doc.page.width;
      const pageHeight = doc.page.height;
      const margin = 40;
      const contentWidth = pageWidth - 2 * margin;
      const footerHeight = 40;
      const usableHeight = pageHeight - footerHeight - margin;

      // Helper function to check if page is full and add new page
      function checkPageBreak(spaceNeeded = 100) {
        if (doc.y + spaceNeeded > usableHeight) {
          doc.addPage();
          drawPageHeader();
        }
      }

      // Draw header on each page
      function drawPageHeader() {
        doc.fontSize(14).font('Helvetica-Bold').fillColor(colors.primary)
          .text(title, margin, margin, { width: contentWidth });
        doc.fontSize(9).font('Helvetica').fillColor(colors.lightText)
          .text(`Generated: ${moment().format('YYYY-MM-DD HH:mm:ss')}`, margin, doc.y + 2);
        doc.moveDown(1.2);
      }

      // Draw table header
      function drawTableHeader() {
        const y = doc.y;
        const headers = ['Item', 'SKU', 'Qty', 'Unit Price', 'Subtotal'];
        const colX = [margin, margin + 160, margin + 240, margin + 290, margin + 370];

        // Background
        doc.rect(margin, y, contentWidth, 22).fill(colors.lightBg);

        // Text
        headers.forEach((header, i) => {
          doc.fontSize(9).font('Helvetica-Bold').fillColor(colors.primary)
            .text(header, colX[i], y + 6, { width: 80, align: ['left', 'left', 'center', 'right', 'right'][i] });
        });

        doc.strokeColor(colors.border).lineWidth(1)
          .moveTo(margin, y + 22).lineTo(margin + contentWidth, y + 22).stroke();

        doc.moveDown(1.8);
      }

      // Draw order item row
      function drawItemRow(item, rowIndex) {
        const y = doc.y;
        const colX = [margin, margin + 160, margin + 240, margin + 290, margin + 370];

        // Alternating row background
        if (rowIndex % 2 === 0) {
          doc.rect(margin, y - 2, contentWidth, 18).fill(colors.lightBg);
        }

        const subtotal = (item.quantity * item.price).toFixed(2);
        const rows = [
          item.productId?.name || item.productName || 'Unknown Product',
          item.productId?.sku || item.sku || 'N/A',
          item.quantity.toString(),
          `$${parseFloat(item.price).toFixed(2)}`,
          `$${subtotal}`
        ];

        rows.forEach((text, i) => {
          doc.fontSize(8).font('Helvetica').fillColor(colors.text)
            .text(text, colX[i], y + 3, {
              width: 75,
              align: ['left', 'left', 'center', 'right', 'right'][i],
              ellipsis: true
            });
        });

        doc.moveDown(1.2);
      }

      // Draw order summary section
      function drawOrderSummary(order) {
        checkPageBreak(160);

        const y = doc.y;
        doc.fontSize(11).font('Helvetica-Bold').fillColor(colors.primary)
          .text(`Order #${order.orderNumber || order._id}`, margin, y);

        const infoY = doc.y + 5;
        const col1 = margin;
        const col2 = margin + contentWidth / 2;

        // Left column
        doc.fontSize(8).font('Helvetica').fillColor(colors.text);
        doc.text(`Customer: ${order.userId?.email || order.customerEmail || 'N/A'}`, col1, infoY);
        doc.text(`Order Date: ${moment(order.createdAt).format('YYYY-MM-DD HH:mm')}`, col1, doc.y);

        // Status
        const statusY = doc.y;
        doc.text(`Status: `, col1, statusY);

        const statusColors = {
          pending: colors.warning,
          'refund requested': '#e74c3c',
          processing: colors.accent,
          shipped: colors.success,
          delivered: colors.success,
          cancelled: '#e74c3c'
        };
        const statusText = order.status?.toLowerCase() || 'n/a';
        const statusColor = statusColors[statusText] || colors.secondary;
        doc.fillColor(statusColor).fontSize(7).font('Helvetica-Bold')
          .text(order.status?.toUpperCase() || 'N/A', col1 + 45, statusY);

        // Right column
        doc.fontSize(8).font('Helvetica').fillColor(colors.text);
        doc.text(`Shipping Address:`, col2, infoY);
        const address = order.shippingAddress || {};
        const addressText = `${address.street || 'N/A'}, ${address.city || ''} ${address.state || ''} ${address.zip || ''}`.trim();
        doc.fontSize(7).text(addressText, col2, doc.y, { width: contentWidth / 2 - 10 });

        doc.moveDown(0.8);
        doc.strokeColor(colors.border).lineWidth(0.5)
          .moveTo(margin, doc.y).lineTo(margin + contentWidth, doc.y).stroke();
        doc.moveDown(0.5);

        drawTableHeader();

        // Items
        order.items.forEach((item, idx) => {
          checkPageBreak(100);
          drawItemRow(item, idx);
        });

        // Order totals
        const rightCol = margin + contentWidth - 150;

        doc.moveDown(0.2);
        doc.fontSize(8).font('Helvetica').fillColor(colors.text);

        const subtotal = order.items.reduce((sum, item) => sum + (item.quantity * item.price), 0);
        const tax = order.tax || 0;
        const shipping = order.shipping || 0;
        const total = order.total || (subtotal + tax + shipping);

        doc.text(`Subtotal:`, rightCol, doc.y);
        doc.text(`$${subtotal.toFixed(2)}`, rightCol + 90, doc.y - 11, { align: 'right' });

        if (tax > 0) {
          doc.text(`Tax:`, rightCol, doc.y);
          doc.text(`$${tax.toFixed(2)}`, rightCol + 90, doc.y - 11, { align: 'right' });
        }

        if (shipping > 0) {
          doc.text(`Shipping:`, rightCol, doc.y);
          doc.text(`$${shipping.toFixed(2)}`, rightCol + 90, doc.y - 11, { align: 'right' });
        }

        // Total (highlighted)
        doc.moveDown(0.3);
        const totalBoxY = doc.y;
        doc.rect(rightCol - 5, totalBoxY, 145, 20).fill(colors.accent);
        doc.fontSize(9).font('Helvetica-Bold').fillColor('#ffffff')
          .text(`Total:`, rightCol, totalBoxY + 4);
        doc.text(`$${total.toFixed(2)}`, rightCol + 90, totalBoxY + 4, { align: 'right' });

        doc.moveDown(1.8);
        doc.strokeColor(colors.border).lineWidth(1.5)
          .moveTo(margin, doc.y).lineTo(margin + contentWidth, doc.y).stroke();
        doc.moveDown(0.8);
      }

      // Main report generation
      drawPageHeader();

      if (!orders || orders.length === 0) {
        doc.fontSize(14).fillColor(colors.lightText)
          .text('No orders available.', { align: 'center' });
      } else {
        orders.forEach((order) => {
          drawOrderSummary(order);
        });

        // Summary page
        checkPageBreak(200);
        doc.fontSize(13).font('Helvetica-Bold').fillColor(colors.primary)
          .text('Report Summary', margin, doc.y);
        doc.moveDown(0.8);

        const totalOrders = orders.length;
        const grandTotal = orders.reduce((sum, order) => sum + (order.total || 0), 0);
        const totalItems = orders.reduce((sum, order) => sum + (order.items?.length || 0), 0);
        const avgOrderValue = (grandTotal / totalOrders).toFixed(2);

        const summaryData = [
          { label: 'Total Orders:', value: totalOrders },
          { label: 'Total Items:', value: totalItems },
          { label: 'Grand Total:', value: `$${grandTotal.toFixed(2)}` },
          { label: 'Average Order Value:', value: `$${avgOrderValue}` }
        ];

        summaryData.forEach((item) => {
          doc.fontSize(10).font('Helvetica-Bold').fillColor(colors.primary)
            .text(item.label, margin, doc.y);
          doc.fontSize(10).font('Helvetica').fillColor(colors.accent)
            .text(item.value, margin + 180, doc.y - 15);
          doc.moveDown(0.5);
        });
      }

      // Add page numbers AFTER all content is added
      doc.on('end', () => {
        const range = doc.bufferedPageRange();
        for (let i = 0; i < range.count; i++) {
          doc.switchToPage(i);
          doc.fontSize(9).fillColor(colors.lightText)
            .text(`Page ${i + 1} of ${range.count}`, margin, pageHeight - 25, {
              align: 'center',
              width: contentWidth
            });
        }
      });

      doc.end();
      stream.on('finish', () => resolve(filePath));
      stream.on('error', reject);
    } catch (error) {
      reject(error);
    }
  });
}

// async function generatePDFReport(orders, filePath, title = 'Order Report', companyInfo = {}) {
//   return new Promise((resolve, reject) => {
//     try {
//       const doc = new PDFDocument({
//         size: 'A4',
//         margin: 45,
//         bufferPages: true
//       });

//       const stream = fs.createWriteStream(filePath);
//       doc.pipe(stream);

//       // Professional color palette
//       const colors = {
//         darkBlue: '#1a2f4b',
//         primary: '#0066cc',
//         accent: '#00a8ff',
//         success: '#10b981',
//         warning: '#f59e0b',
//         danger: '#ef4444',
//         lightGray: '#f8f9fa',
//         gray: '#9ca3af',
//         darkGray: '#374151',
//         white: '#ffffff',
//         black: '#000000'
//       };

//       const pageWidth = doc.page.width;
//       const pageHeight = doc.page.height;
//       const margin = 45;
//       const contentWidth = pageWidth - 2 * margin;

//       // ========== HELPER FUNCTIONS ==========

//       function drawHeader() {
//         // Top gradient bar
//         doc.rect(0, 0, pageWidth, 95).fill(colors.darkBlue);

//         // Company info
//         doc.fontSize(20).font('Helvetica-Bold').fillColor(colors.white)
//           .text(companyInfo.name || 'ECOMMERCE STORE', margin, 20);

//         doc.fontSize(9).font('Helvetica').fillColor(colors.accent)
//           .text(companyInfo.tagline || 'Order Management System', margin, 48);

//         // Report title on right
//         doc.fontSize(13).font('Helvetica-Bold').fillColor(colors.white)
//           .text(title, margin, 62, { align: 'right', width: contentWidth });

//         doc.fontSize(8).font('Helvetica').fillColor(colors.accent)
//           .text(`Generated: ${moment().format('MMM DD, YYYY • HH:mm')}`, margin, 80, { align: 'right', width: contentWidth });
//       }

//       function drawTableHeader() {
//         const y = doc.y;

//         // Header background
//         doc.rect(margin, y - 5, contentWidth, 25).fill(colors.darkBlue);

//         // Column positions
//         const col = {
//           item: { x: margin + 10, width: 160 },
//           sku: { x: margin + 175, width: 65 },
//           qty: { x: margin + 250, width: 45 },
//           price: { x: margin + 305, width: 70 },
//           subtotal: { x: margin + 385, width: 75 }
//         };

//         // Headers
//         doc.fontSize(9).font('Helvetica-Bold').fillColor(colors.white);
//         doc.text('Item', col.item.x, y);
//         doc.text('SKU', col.sku.x, y, { align: 'center' });
//         doc.text('Qty', col.qty.x, y, { align: 'center' });
//         doc.text('Unit Price', col.price.x, y, { align: 'right' });
//         doc.text('Subtotal', col.subtotal.x, y, { align: 'right' });

//         doc.moveDown(1.8);
//       }

//       function drawItemRow(item, rowIndex) {
//         const y = doc.y;

//         // Alternating background
//         if (rowIndex % 2 === 0) {
//           doc.rect(margin, y - 3, contentWidth, 18).fill(colors.lightGray);
//         }

//         const col = {
//           item: { x: margin + 10, width: 160 },
//           sku: { x: margin + 175, width: 65 },
//           qty: { x: margin + 250, width: 45 },
//           price: { x: margin + 305, width: 70 },
//           subtotal: { x: margin + 385, width: 75 }
//         };

//         const subtotal = (item.quantity * item.price).toFixed(2);

//         doc.fontSize(9).font('Helvetica').fillColor(colors.darkGray);

//         // Item name
//         doc.text(
//           item.productId?.name || item.productName || 'Unknown Product',
//           col.item.x,
//           y,
//           { width: col.item.width, ellipsis: true }
//         );

//         // SKU
//         doc.text(
//           item.productId?.sku || item.sku || 'N/A',
//           col.sku.x,
//           y,
//           { width: col.sku.width, align: 'center' }
//         );

//         // Qty
//         doc.text(
//           item.quantity.toString(),
//           col.qty.x,
//           y,
//           { width: col.qty.width, align: 'center' }
//         );

//         // Price
//         doc.text(
//           `$${parseFloat(item.price).toFixed(2)}`,
//           col.price.x,
//           y,
//           { width: col.price.width, align: 'right' }
//         );

//         // Subtotal
//         doc.fontSize(9).font('Helvetica-Bold').fillColor(colors.primary)
//           .text(
//             `$${subtotal}`,
//             col.subtotal.x,
//             y,
//             { width: col.subtotal.width, align: 'right' }
//           );

//         doc.moveDown(1.3);
//       }

//       function getStatusColor(status) {
//         const statusLower = status?.toLowerCase() || '';
//         const statusMap = {
//           'pending': colors.warning,
//           'refund requested': colors.danger,
//           'processing': colors.accent,
//           'shipped': colors.primary,
//           'delivered': colors.success,
//           'cancelled': colors.danger
//         };
//         return statusMap[statusLower] || colors.gray;
//       }

//       function drawStatusBadge(status, x, y) {
//         const bgColor = getStatusColor(status);
//         const text = status?.toUpperCase() || 'N/A';

//         // Badge background rounded (simulated with rect)
//         doc.rect(x, y, 95, 20).fill(bgColor);

//         // Badge text
//         doc.fontSize(8).font('Helvetica-Bold').fillColor(colors.white)
//           .text(text, x, y + 5, {
//             width: 95,
//             align: 'center'
//           });
//       }

//       function checkPageBreak(spaceNeeded = 120) {
//         if (doc.y + spaceNeeded > pageHeight - 60) {
//           doc.addPage();
//           drawHeader();
//           doc.moveDown(7);
//         }
//       }

//       function drawOrderSummary(order) {
//         checkPageBreak(200);

//         const y = doc.y;

//         // Order card header with accent bar
//         doc.rect(margin, y, 4, 35).fill(colors.primary);
//         doc.rect(margin + 4, y, contentWidth - 4, 35).stroke(colors.primary);

//         // Order number and date
//         doc.fontSize(11).font('Helvetica-Bold').fillColor(colors.darkBlue)
//           .text(`Order #${order.orderNumber || order._id}`, margin + 15, y + 6);

//         doc.fontSize(8).font('Helvetica').fillColor(colors.gray)
//           .text(`${moment(order.createdAt).format('MMM DD, YYYY @ HH:mm')}`, margin + 15, y + 22);

//         // Status badge on the right
//         const statusX = margin + contentWidth - 105;
//         drawStatusBadge(order.status, statusX, y + 7);

//         doc.moveDown(3);

//         // Customer and Address section
//         const leftColX = margin;
//         const rightColX = margin + contentWidth / 2 + 10;

//         // Left: Customer Info
//         doc.fontSize(9).font('Helvetica-Bold').fillColor(colors.primary)
//           .text('CUSTOMER', leftColX, doc.y);

//         doc.fontSize(8).font('Helvetica').fillColor(colors.darkGray);
//         const email = order.userId?.email || order.customerEmail || 'N/A';
//         doc.text(`${email}`, leftColX, doc.y + 12);
//         doc.text(`Phone: ${order.phone || 'N/A'}`, leftColX, doc.y);

//         // Right: Shipping Address
//         doc.fontSize(9).font('Helvetica-Bold').fillColor(colors.primary)
//           .text('SHIPPING ADDRESS', rightColX, doc.y - 24);

//         const address = order.shippingAddress || {};
//         doc.fontSize(8).font('Helvetica').fillColor(colors.darkGray);
//         const street = address.street || 'N/A';
//         const city = address.city || '';
//         const state = address.state || '';
//         const zip = address.zip || '';
//         doc.text(`${street}`, rightColX, doc.y + 12);
//         doc.text(`${city}, ${state} ${zip}`, rightColX, doc.y);

//         doc.moveDown(2.5);

//         // Separator line
//         doc.strokeColor(colors.lightGray).lineWidth(1)
//           .moveTo(margin, doc.y).lineTo(margin + contentWidth, doc.y).stroke();

//         doc.moveDown(1);

//         // Items table
//         drawTableHeader();

//         order.items.forEach((item, idx) => {
//           checkPageBreak(80);
//           drawItemRow(item, idx);
//         });

//         // Order totals section
//         const totalsX = margin + contentWidth - 180;
//         doc.moveDown(0.3);

//         const subtotal = order.items.reduce((sum, item) => sum + (item.quantity * item.price), 0);
//         const tax = order.tax || 0;
//         const shipping = order.shipping || 0;
//         const total = order.total || (subtotal + tax + shipping);

//         // Subtotal
//         doc.fontSize(8).font('Helvetica').fillColor(colors.darkGray)
//           .text('Subtotal:', totalsX, doc.y);
//         doc.fontSize(9).font('Helvetica-Bold').fillColor(colors.darkGray)
//           .text(`$${subtotal.toFixed(2)}`, totalsX + 110, doc.y - 11, { align: 'right' });

//         // Tax
//         if (tax > 0) {
//           doc.moveDown(1);
//           doc.fontSize(8).font('Helvetica').fillColor(colors.darkGray)
//             .text('Tax:', totalsX, doc.y);
//           doc.fontSize(9).font('Helvetica-Bold').fillColor(colors.darkGray)
//             .text(`$${tax.toFixed(2)}`, totalsX + 110, doc.y - 11, { align: 'right' });
//         }

//         // Shipping
//         if (shipping > 0) {
//           doc.moveDown(1);
//           doc.fontSize(8).font('Helvetica').fillColor(colors.darkGray)
//             .text('Shipping:', totalsX, doc.y);
//           doc.fontSize(9).font('Helvetica-Bold').fillColor(colors.darkGray)
//             .text(`$${shipping.toFixed(2)}`, totalsX + 110, doc.y - 11, { align: 'right' });
//         }

//         // Total box
//         doc.moveDown(1.3);
//         const totalBoxY = doc.y;
//         doc.rect(totalsX - 10, totalBoxY, 180, 28).fill(colors.primary);
//         doc.fontSize(10).font('Helvetica-Bold').fillColor(colors.white)
//           .text('TOTAL:', totalsX, totalBoxY + 6);
//         doc.text(`$${total.toFixed(2)}`, totalsX + 110, totalBoxY + 6, { align: 'right' });

//         doc.moveDown(2.8);
//       }

//       function drawSummaryPage(orders) {
//         doc.addPage();
//         drawHeader();
//         doc.moveDown(7);

//         doc.fontSize(13).font('Helvetica-Bold').fillColor(colors.darkBlue)
//           .text('REPORT SUMMARY', margin, doc.y);
//         doc.moveDown(1.5);

//         const totalOrders = orders.length;
//         const grandTotal = orders.reduce((sum, order) => sum + (order.total || 0), 0);
//         const totalItems = orders.reduce((sum, order) => sum + (order.items?.length || 0), 0);
//         const avgOrderValue = (grandTotal / totalOrders).toFixed(2);

//         // Statistics boxes
//         const stats = [
//           { label: 'Total Orders', value: totalOrders.toString(), icon: '📦' },
//           { label: 'Total Items', value: totalItems.toString(), icon: '🛒' },
//           { label: 'Grand Total', value: `$${grandTotal.toFixed(2)}`, icon: '💰' },
//           { label: 'Avg Order Value', value: `$${avgOrderValue}`, icon: '📊' }
//         ];

//         stats.forEach((stat, i) => {
//           const boxX = margin + (i % 2) * (contentWidth / 2 + 10);
//           const boxY = doc.y + (Math.floor(i / 2) * 85);

//           // Box background
//           doc.rect(boxX, boxY, contentWidth / 2 - 5, 75).fill(colors.lightGray);

//           // Icon
//           doc.fontSize(24).text(stat.icon, boxX + 15, boxY + 15);

//           // Label
//           doc.fontSize(9).font('Helvetica').fillColor(colors.gray)
//             .text(stat.label, boxX + 60, boxY + 20);

//           // Value
//           doc.fontSize(16).font('Helvetica-Bold').fillColor(colors.primary)
//             .text(stat.value, boxX + 60, boxY + 35);
//         });

//         doc.moveDown(9);

//         // Status breakdown
//         doc.fontSize(11).font('Helvetica-Bold').fillColor(colors.darkBlue)
//           .text('ORDER STATUS BREAKDOWN', margin, doc.y);
//         doc.moveDown(1);

//         const statusBreakdown = {};
//         orders.forEach(order => {
//           const status = order.status?.toLowerCase() || 'unknown';
//           statusBreakdown[status] = (statusBreakdown[status] || 0) + 1;
//         });

//         Object.entries(statusBreakdown).forEach(([status, count]) => {
//           const percentage = ((count / totalOrders) * 100).toFixed(1);
//           const barWidth = (count / totalOrders) * 250;

//           doc.fontSize(9).font('Helvetica').fillColor(colors.darkGray)
//             .text(`${status.toUpperCase()}`, margin, doc.y);

//           // Progress bar background
//           doc.rect(margin + 120, doc.y - 3, 250, 14).stroke(colors.lightGray);

//           // Progress bar fill
//           doc.rect(margin + 120, doc.y - 3, barWidth, 14).fill(getStatusColor(status));

//           // Percentage text
//           doc.fontSize(8).font('Helvetica-Bold').fillColor(colors.white)
//             .text(`${percentage}% (${count})`, margin + 130 + barWidth / 2 - 25, doc.y + 1);

//           doc.moveDown(1.8);
//         });
//       }

//       // ========== MAIN EXECUTION ==========

//       drawHeader();
//       doc.moveDown(7);

//       if (!orders || orders.length === 0) {
//         doc.fontSize(14).fillColor(colors.gray)
//           .text('No orders available for this period.', { align: 'center' });
//       } else {
//         orders.forEach((order) => {
//           drawOrderSummary(order);
//         });

//         drawSummaryPage(orders);
//       }

//       // Add page numbers
//       doc.on('end', () => {
//         const range = doc.bufferedPageRange();
//         for (let i = 0; i < range.count; i++) {
//           doc.switchToPage(i);
//           doc.fontSize(8).fillColor(colors.gray)
//             .text(`Page ${i + 1} of ${range.count}`, margin, pageHeight - 30, {
//               align: 'center',
//               width: contentWidth
//             });
//         }
//       });

//       doc.end();
//       stream.on('finish', () => resolve(filePath));
//       stream.on('error', reject);
//     } catch (error) {
//       reject(error);
//     }
//   });
// }

// Alternative simple version for basic needs
async function generateSimplePDFReport(orders, filePath, title = 'Order Report') {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      margin: 50,
      size: 'A4',
      compress: true // Critical for preventing corruption
    });

    const stream = fs.createWriteStream(filePath);
    doc.pipe(stream);

    // Simple header
    doc.fontSize(20)
      .text(title, { align: 'center' })
      .moveDown();

    // Simple content
    orders.forEach((order, index) => {
      // Prevent text encoding issues
      const safeText = (text) => String(text || '').replace(/[^\x00-\x7F]/g, '') || 'N/A';

      doc.fontSize(12)
        .text(`Order: ${safeText(order._id)}`)
        .text(`Customer: ${safeText(order.userId?.email)}`)
        .text(`Total: $${(order.total || 0).toFixed(2)}`)
        .text(`Status: ${safeText(order.status)}`)
        .text(`Date: ${order.createdAt ? moment(order.createdAt).format('YYYY-MM-DD') : 'N/A'}`)
        .moveDown();

      // Simple page break check
      if (index % 10 === 0 && index > 0) {
        doc.addPage();
      }
    });

    doc.end();

    stream.on('finish', () => resolve(filePath));
    stream.on('error', (error) => {
      console.error('Stream error:', error);
      reject(new Error(`PDF creation failed: ${error.message}`));
    });
  });
}

// Test function to verify PDF generation
async function testPDFGeneration() {
  const testOrders = [
    {
      _id: 'ORD001',
      userId: { email: 'test@example.com' },
      total: 100.50,
      status: 'completed',
      createdAt: new Date(),
      items: [{ productId: { name: 'Test Product' }, quantity: 1, price: 100.50 }]
    }
  ];

  try {
    const filePath = await generateRobustPDFReport(
      testOrders,
      './reports/test-report.pdf',
      {
        title: 'Test Report',
        company: 'Test Company'
      }
    );

    console.log('✅ PDF generated successfully:', filePath);

    // Verify file exists and has content
    const stats = fs.statSync(filePath);
    if (stats.size > 0) {
      console.log('✅ File is not corrupted, size:', stats.size, 'bytes');
    } else {
      console.log('❌ File is empty - possible corruption');
    }

    return filePath;
  } catch (error) {
    console.error('❌ PDF generation failed:', error);
    throw error;
  }
}

// Schedule daily report at 23:59
cron.schedule('28 23 * * *', async () => {
  try {
    const startOfDay = moment().startOf('day').toDate();
    const orders = await Order.find({ createdAt: { $gte: startOfDay } })
      .populate('userId', 'email')
      .populate('items.productId');
    if (orders.length) {
      const filePath = `./reports/daily/daily-report-${moment().format('YYYY-MM-DD')}.pdf`;
      await generatePDFReport(orders, filePath, `Daily Orders Report - ${moment().format('YYYY-MM-DD')}`);
      console.log('✅ Daily report generated:', filePath);
    }
  } catch (err) {
    console.error('❌ Error generating daily report:', err.message);
  }
});

// Schedule monthly report on 1st of every month at 00:00
cron.schedule('0 0 1 * *', async () => {
  try {
    const startOfMonth = moment().startOf('month').toDate();
    const orders = await Order.find({ createdAt: { $gte: startOfMonth } })
      .populate('userId', 'email')
      .populate('items.productId');
    if (orders.length) {
      const filePath = `./reports/monthly/monthly-report-${moment().format('YYYY-MM')}.pdf`;
      await generatePDFReport(orders, filePath, `Monthly Orders Report - ${moment().format('MMMM YYYY')}`);
      console.log('✅ Monthly report generated:', filePath);
    }
  } catch (err) {
    console.error('❌ Error generating monthly report:', err.message);
  }
});


// List available reports
router.get('/admin/reports/:type', verifyToken, async (req, res) => {
  try {
    const admin = await Admin.findById(req.user.id);
    if (!admin || admin.role !== 'admin') {
      return res.status(403).json({ message: 'Admin access required' });
    }

    const { type } = req.params; // daily or monthly
    const folder = type === 'daily' ? './reports/daily' : './reports/monthly';
    const files = await fs.readdir(folder);

    const reports = files.map(file => ({
      name: file,
      date: type === 'daily' ? file.replace('daily-report-', '').replace('.pdf', '') : file.replace('monthly-report-', '').replace('.pdf', ''),
      path: `/admin/reports/${type}/download/${file}`
    }));

    res.json(reports);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// Download specific report
router.get('/admin/reports/:type/download/:filename', verifyToken, async (req, res) => {
  try {
    const admin = await Admin.findById(req.user.id);
    if (!admin || admin.role !== 'admin') {
      return res.status(403).json({ message: 'Admin access required' });
    }

    const { type, filename } = req.params;
    const folder = type === 'daily' ? './reports/daily' : './reports/monthly';
    const filePath = path.join(folder, filename);

    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: 'Report not found' });
    }

    res.download(filePath);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;