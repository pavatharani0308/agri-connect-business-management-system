const express = require("express");
const router = express.Router();
const Feedback = require("../models/Feedback"); // Adjust the path as needed
const authMiddleware = require('../middleware/authMiddleware');

// Handle POST request to submit feedback
router.post("/feedback", async (req, res) => {
  const { name, email, message } = req.body;

  try {
    const newFeedback = new Feedback({ name, email, message });
    await newFeedback.save();
    res.status(200).json({ message: "Feedback submitted successfully!" });
  } catch (error) {
    console.error("Error saving feedback:", error);
    res.status(500).json({ message: "Error saving feedback. Please try again." });
  }
});

// Handle GET request to fetch all feedback
router.get("/feedback", async (req, res) => {
  try {
    const feedbacks = await Feedback.find(); // Fetch all feedbacks
    res.status(200).json(feedbacks);
  } catch (error) {
    console.error("Error fetching feedbacks:", error);
    res.status(500).json({ message: "Error fetching feedbacks." });
  }
});

// Handle POST request to reply to feedback
router.post("/feedback/:id/reply", async (req, res) => {
  const { id } = req.params;
  const { adminReply } = req.body; // Get the reply from request body

  try {
    const feedback = await Feedback.findById(id);
    if (!feedback) {
      return res.status(404).json({ message: "Feedback not found." });
    }

    feedback.replies.push({ adminReply }); // Add the reply to the replies array
    await feedback.save();

    res.status(200).json({ message: "Reply added successfully!", feedback });
  } catch (error) {
    console.error("Error replying to feedback:", error);
    res.status(500).json({ message: "Error adding reply. Please try again." });
  }
});

// Handle DELETE request to delete a specific reply
router.delete("/feedback/:feedbackId/reply/:replyIndex", async (req, res) => {
  const { feedbackId, replyIndex } = req.params;

  try {
    const feedback = await Feedback.findById(feedbackId);
    if (!feedback) {
      return res.status(404).json({ message: "Feedback not found." });
    }

    if (feedback.replies.length <= replyIndex || replyIndex < 0) {
      return res.status(404).json({ message: "Reply not found." });
    }

    feedback.replies.splice(replyIndex, 1); // Remove the reply at the specified index
    await feedback.save();

    res.status(200).json({ message: "Reply deleted successfully!", feedback });
  } catch (error) {
    console.error("Error deleting reply:", error);
    res.status(500).json({ message: "Error deleting reply. Please try again." });
  }
});

// Handle DELETE request to delete feedback
router.delete("/feedback/:id", async (req, res) => {
  const { id } = req.params; // Extract feedback ID from the request

  try {
    const feedback = await Feedback.findByIdAndDelete(id); // Find and delete the feedback

    if (!feedback) {
      return res.status(404).json({ message: "Feedback not found." }); // Return 404 if feedback is not found
    }

    res.status(200).json({ message: "Feedback deleted successfully!" }); // Success message
  } catch (error) {
    console.error("Error deleting feedback:", error); // Log any errors
    res.status(500).json({ message: "Error deleting feedback. Please try again." }); // Handle errors
  }
});

// PATCH request to toggle like/unlike
// PATCH request to toggle like/unlike
router.patch("/feedback/:id/like", async (req, res) => {
  const { id } = req.params;
  const userId = "testUserId"; // Temporary hardcoded userId for testing

  try {
    const feedback = await Feedback.findById(id);
    if (!feedback) {
      return res.status(404).json({ message: "Feedback not found." });
    }

    // Initialize likedBy array if it doesn't exist
    if (!feedback.likedBy) {
      feedback.likedBy = [];
      feedback.likes = 0; // Initialize likes count if it doesn't exist
    }

    // Check if the user has already liked the feedback
    const userHasLiked = feedback.likedBy.includes(userId);

    if (userHasLiked) {
      // Unlike: Remove userId from likedBy array and decrement likes
      feedback.likedBy = feedback.likedBy.filter((user) => user !== userId);
      feedback.likes = Math.max(0, feedback.likes - 1); // Prevent likes from going below 0
    } else {
      // Like: Add userId to likedBy array and increment likes
      feedback.likedBy.push(userId);
      feedback.likes += 1;
    }

    // Save the updated feedback to the database
    await feedback.save();

    // Send back the updated like count and status
    res.status(200).json({ likes: feedback.likes, userHasLiked: !userHasLiked });
  } catch (error) {
    console.error("Error toggling like:", error);
    res.status(500).json({ message: "Error toggling like." });
  }
});


// Update a reply for a specific feedback
router.put("/feedback/:feedbackId/reply/:replyIndex", async (req, res) => {
  const { feedbackId, replyIndex } = req.params;
  const { adminReply } = req.body;

  try {
    const feedback = await Feedback.findById(feedbackId);

    if (!feedback) {
      return res.status(404).json({ message: 'Feedback not found' });
    }

    // Check if the reply exists, then update it
    if (feedback.replies[replyIndex]) {
      feedback.replies[replyIndex].adminReply = adminReply;
      await feedback.save();

      return res.json({ message: 'Reply updated successfully', feedback });
    } else {
      return res.status(404).json({ message: 'Reply not found' });
    }
  } catch (error) {
    console.error('Error updating reply:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
